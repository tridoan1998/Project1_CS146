Name: Tri Doan
Course: CS 146
Date: 09/15/2019

Data Shuffling
Description
You are assigned to implement andata shuffling project that gives a dataset and produces a new one shuffled
(permutation of the original dataset). Each row is considered an element.Use  the  Fisher–Yates  shuffle 
algorithm  that  works  in  O(n) running  time,  that  relies  on  creatingpseudo-random numbers
(see end for help) in O(1) running time.

Circular linked list game
Description
In an ancient land, a King had many prisoners. He decided on the following procedure to determine
 which prisoner to grand freedom. First, all of the prisoners would be lined up one after the other and
 assigned numbers. The first prisoner would be number 1,the second number 2, and so on up to the
 last prisoner, number n . Starting at the prisoner in the first position, he would then count k prisoners
 down the line, and the kth prisoner would be eliminated from winning her/his freedom removed from the line.
The King would then continue, counting k more prisoners, and eliminate every kth prisoner.
 When he reached the end ofthe line, he would continue counting from the beginning.